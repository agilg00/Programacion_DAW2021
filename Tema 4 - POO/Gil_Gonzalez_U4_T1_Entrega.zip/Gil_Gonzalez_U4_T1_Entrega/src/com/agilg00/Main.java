package com.agilg00;

public class Main {

    public static void main(String[] args) {
	// write your code here
        
        Personaje p1 = new Personaje("Sonic", 100.00, 100, 20);




        

    }
}
