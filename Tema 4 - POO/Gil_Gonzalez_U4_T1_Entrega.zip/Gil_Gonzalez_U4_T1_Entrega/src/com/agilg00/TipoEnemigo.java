package com.agilg00;

public enum TipoEnemigo {

    BuzzBomber,
    CrabMeat,
    Coconuts,
    Chopper,
    MotoBug
}
